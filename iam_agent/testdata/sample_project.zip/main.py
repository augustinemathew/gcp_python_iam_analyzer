from google.cloud import storage
from google.cloud import bigquery

def upload_file(bucket_name, source_file, dest_blob):
    client = storage.Client()
    bucket = client.get_bucket(bucket_name)
    blob = bucket.blob(dest_blob)
    blob.upload_from_filename(source_file)

def run_query(query):
    client = bigquery.Client()
    result = client.query(query)
    return list(result)
